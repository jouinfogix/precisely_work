import psycopg2
import logging
import boto3
import os
import sys
from datetime import datetime
from base64 import b64decode

bucketname = "customuserreport.sagacity.infogix.com"

host1 = os.environ['host1']
db_name1 = os.environ['db_name1']
user1 = boto3.client('kms').decrypt(CiphertextBlob=b64decode(os.environ['user1']))['Plaintext']
password1 = boto3.client('kms').decrypt(CiphertextBlob=b64decode(os.environ['password1']))['Plaintext']
port1 = os.environ['port1']

host2 = os.environ['host2']
db_name2 = os.environ['db_name2']
user2 = boto3.client('kms').decrypt(CiphertextBlob=b64decode(os.environ['user2']))['Plaintext']
password2 = boto3.client('kms').decrypt(CiphertextBlob=b64decode(os.environ['password2']))['Plaintext']
port2 = os.environ['port2']



logger = logging.getLogger()
logger.setLevel(logging.INFO)

def process_data():
    db_attrib = DB_Attribute(host1, db_name1, str(user1), str(password1), port1)
    quries = Queries("\"OrgID\",\"gigabytes\"", "SELECT SUBSTRING(\"table\", 4, 4) AS OrgID, CAST(SUM(size)/1024.00 AS DECIMAL(18, 2)) AS gigabytes FROM SVV_TABLE_INFO WHERE \"table\" LIKE 'ds_%' GROUP BY SUBSTRING(\"table\", 4, 4) ORDER BY 2 DESC")
    file_attribute = File_Attribute(bucketname, folder_cercreation(), 'redshift_igxcafeprodhp_prod')
    generate_report(db_attrib, quries, file_attribute)
    
    db_attrib = DB_Attribute(host2, db_name2, str(user2), str(password2), port2)
    file_attribute = File_Attribute(bucketname, folder_cercreation(), 'redshift_igxcafeprodreg_prod')
    generate_report(db_attrib, quries, file_attribute)
    
def generate_report(db_attrib, quries, file_attribute):
    column_delimiter = ','
    column_textqualifier = '\"'
    connstr = db_attrib.connstr
    #result = ""
    result = []
    sql_columns = quries.sql_columns
    sql_content = quries.sql_content
    
    result.append(sql_columns)
    
    try:
        conn=psycopg2.connect(connstr)
    except:
        #print("I am unable to connect to the database.")
        print("Unexpected error:", sys.exc_info()[0])
        raise
    
    cur = conn.cursor()
    
    try:
        cur.execute(sql_content)
    except:
        print("I can't SELECT from bar")

    rows = cur.fetchall()
    for row in rows:
        result.append("\n")
        i = 0
        for col in row:
            if(i > 0):
                result.append(column_delimiter)
                result.append(column_textqualifier)
                result.append(str(col))
                result.append(column_textqualifier)
            else:
                result.append(column_textqualifier)
                result.append(str(col))
                result.append(column_textqualifier)
            i = i + 1
    
    #print(result)
    save_string_to_s3(file_attribute, ''.join(result))

def save_string_to_s3(file_attribute, result):
    s3 = boto3.resource('s3')
    object = s3.Object(file_attribute.bucketname, file_attribute.reportfilename)
    object.put(Body=result)

def folder_cercreation():
    return datetime.today().strftime('%Y_%m_%d')

def lambda_handler(event, context):
    process_data()
    
class DB_Attribute:
    def __init__(self, host, db_name, user, password, port):
        self.host = host
        self.db_name = db_name
        self.user = user.replace("b'", "").replace("'", "")
        self.password = password.replace("b'", "").replace("'", "")
        self.port = port
        self.connstr = "host='" + self.host + "' dbname='" + self.db_name + "' user='" + self.user + "' password='" + self.password + "' port='" + str(self.port) + "'"
    
class Queries():
    def __init__(self, columns, sql_content):
        self.sql_columns = columns
        self.sql_content = sql_content

class File_Attribute:
    def __init__(self, bucketname, filepath, reportname):
        self.bucketname = bucketname
        self.reportname = reportname
        self.reportfilename = filepath + '/' + self.reportname + '.csv'
        